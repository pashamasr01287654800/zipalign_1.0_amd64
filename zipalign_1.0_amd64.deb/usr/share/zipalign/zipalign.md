#!/bin/bash
# install_zipalign_as_mv.sh
# Purpose:
#   - Copy system mv binary to /bin/zipalign (overwrite if exists)
#   - Install a wrapper at /usr/local/bin/zipalign that ignores options
#     and calls /bin/zipalign -f <input> <output>
set -euo pipefail

# locate mv binary
MV_BIN="$(command -v mv)"
if [ -z "$MV_BIN" ]; then
  echo "ERROR: 'mv' not found on this system. Aborting." >&2
  exit 1
fi

TARGET_BACKEND="/bin/zipalign"
WRAPPER="/usr/local/bin/zipalign"

# overwrite existing backend and wrapper
sudo rm -f "$TARGET_BACKEND" "$WRAPPER"

echo "Copying mv ($MV_BIN) -> $TARGET_BACKEND"
sudo cp -a "$MV_BIN" "$TARGET_BACKEND"
sudo chmod --reference="$MV_BIN" "$TARGET_BACKEND"
sudo chown --reference="$MV_BIN" "$TARGET_BACKEND"

echo "Installing wrapper at $WRAPPER"
sudo bash -c "cat > $WRAPPER" <<'EOF'
#!/bin/bash
set -euo pipefail

BACKEND="/bin/zipalign"

if [ ! -x "$BACKEND" ]; then
  echo "zipalign wrapper: backend $BACKEND not found or not executable." >&2
  exit 1
fi

files=()
for a in "$@"; do
  case "$a" in
    --) shift; for b in "$@"; do files+=("$b"); done; break ;;
    -*) continue ;;
    *) files+=("$a") ;;
  esac
done

if [ "${#files[@]}" -lt 2 ]; then
  cat <<USAGE >&2
Usage: zipalign [options] <input.apk> <output.apk>
This wrapper ignores options and will run:
  $BACKEND -f <input.apk> <output.apk>
USAGE
  exit 2
fi

infile="${files[$((${#files[@]}-2))]}"
outfile="${files[$((${#files[@]}-1))]}"

exec "$BACKEND" -f "$infile" "$outfile"
EOF

sudo chmod +x "$WRAPPER"
sudo chown --reference="$MV_BIN" "$WRAPPER"

echo "Installed successfully."
echo
echo "Example:"
echo "  zipalign -p 4 injected.apk aligned.apk"
echo "will run -> /bin/zipalign -f injected.apk aligned.apk"
