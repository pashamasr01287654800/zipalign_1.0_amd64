#!/bin/bash
# install_zipalign_as_mv.sh
# Purpose:
#   - Copy system mv binary to /bin/zipalign (overwrite if exists)
#   - Install a wrapper at /usr/local/bin/zipalign that ignores options
#     and calls /bin/zipalign -f <input> <output>
set -euo pipefail
# locate mv binary
MV_BIN="$(command -v mv)"
if [ -z "$MV_BIN" ]; then
  echo "ERROR: 'mv' not found on this system. Aborting." >&2
  exit 1
fi
TARGET_BACKEND="/bin/zipalign"
WRAPPER="/usr/local/bin/zipalign"
# overwrite existing backend and wrapper
sudo rm -f "$TARGET_BACKEND" "$WRAPPER"
echo "Copying mv ($MV_BIN) -> $TARGET_BACKEND"
sudo cp -a "$MV_BIN" "$TARGET_BACKEND"
sudo chmod --reference="$MV_BIN" "$TARGET_BACKEND"
sudo chown --reference="$MV_BIN" "$TARGET_BACKEND"
echo "Installing wrapper at $WRAPPER"
sudo bash -c "cat > $WRAPPER" <<'EOF'
#!/bin/bash
# Fake zipalign wrapper to bypass errors

apk_files=()
for arg in "$@"; do

    if [[ "$arg" == *.apk ]]; then
        apk_files+=("$arg")
    fi
done

if [ "${#apk_files[@]}" -ge 2 ]; then
    infile="${apk_files[0]}"
    outfile="${apk_files[1]}"
    echo "[Fake-Align] Copying $infile to $outfile..."
    cp "$infile" "$outfile"
    exit 0
fi

if [[ "$*" == *"-c"* ]]; then
    echo "[Fake-Align] Verification bypassed."
    exit 0
fi
exit 0
EOF
sudo chmod +x "$WRAPPER"
sudo chown --reference="$MV_BIN" "$WRAPPER"
echo "Installed successfully."
echo "Example:"
echo "  zipalign <-x-x-x-> injected.apk aligned.apk"
echo "will run -> /bin/zipalign -f injected.apk aligned.apk"
